import java.util.*;
public class Customer extends Person {


	int seatID;
	long startTime;
	long endTime;
	
	public Customer(String name) {
		super(name);
		
		

		
	}


}

	 
	 
	 

